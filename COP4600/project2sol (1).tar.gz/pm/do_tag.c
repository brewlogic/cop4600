#include <stdio.h>
#include "pm.h"
#include "mproc.h"
#include <unistd.h>

int do_tag() {
    int flag = m_in.m1_i1;
    int pid = m_in.m1_i2;

    int size = sizeof(mproc)/sizeof(mproc[0]);
    
    
    register struct mproc *rmp;
    
    rmp = find_proc(pid);
    
    if(rmp == NULL){
        return -1;
    }


    if(flag == 0){
      printf("System call do_tag called with value %d and %d\n",flag,pid);
      // printf("The value of tag for pid: %d is %d\n",pid,mproc[index].tag);
      printf("The value of tag for pid: %d is %d\n",pid,rmp->tag);
    }

    else if(flag == 1){
      int new_value = m_in.m1_i3;
        printf("System call do_tag called with value %d,%d, and %d\n",flag,pid,new_value);
        if(new_value < 0){
          printf("Value must be non-negative!\n");
          return -1;
        }
        // mproc[index].tag = new_value;
        rmp->tag = new_value;

        printf("The value of pid: %d is now the value: %d\n",pid,new_value);
    }

    // return mproc[index].tag;
    return rmp->tag;

    // return foundPID;
}

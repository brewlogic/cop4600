#include <lib.h>      // provides _syscall and message
#include <unistd.h>   // provides function prototype (see step 1 below)

int set_tag(int PID, int new_value) {
    message m;      // Minix message to pass parameters to a system call

    m.m1_i1 = 1;  // set first integer to set_tag flag which is 1

    m.m1_i2 = PID; //set second parameter to PID

    m.m1_i3 = new_value; //set third parameter to the new value being passed

    //check for root access
    if(geteuid() != 0){
      return -1;
    }

    return _syscall(PM_PROC_NR, DO_TAG, &m);  // invoke underlying system call
}

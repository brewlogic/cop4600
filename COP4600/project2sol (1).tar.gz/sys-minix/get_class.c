#include <lib.h>      // provides _syscall and message
#include <unistd.h>   // provides function prototype
#include <sys/stat.h> // provides fstat function

int get_class(FILE* fd) {
    message m;      // Minix message to pass parameters to a system call
    struct stat file_stat;	// stat struct to get inode number
    int inode;

    // return error if unable to get file stats
    printf("fstat return val: %d\n",fstat(fileno(fd), &file_stat));
    
    
    printf("runs library getclass\n");
    
    if(fd == NULL){
        errno = -1;
        return -1;
    }


    // get inode number from fstat info
    inode = file_stat.st_ino;
    
    printf("sysminix getclass inode nr: %d\n",inode);

    m.m1_i1 = inode;  // set first integer of message to inode number
    m.m1_i2 = fd;     // set second integer of message to file descriptor (to find endnode)
    
    int r = _syscall(VFS_PROC_NR, 70, &m);  // invoke underlying system call (SET_CLASS)
    
    if(r < 0){
        errno = r;
    }
    
    return r;
}
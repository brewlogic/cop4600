#include <lib.h>      // provides _syscall and message
#include <unistd.h>   // provides function prototype
#include <sys/stat.h> // provides fstat function

int set_class(FILE* fd, int newvalue) {
    message m;      // Minix message to pass parameters to a system call
    struct stat file_stat;	// stat struct to get inode number
    int inode;

    // return error if unable to get file stats
    // if((fstat(fd, &file_stat))<0){
    //     printf("sys-minix fstat break\n");
    // 	return -1;
    // }
    
    
    if(fd == NULL){
        errno = -1;
        return -1;
    }
    
    printf("fstat return val: %d\n",fstat(fileno(fd), &file_stat));
    
    printf("runs library setclass\n");

    // get inode number from fstat info
    inode = file_stat.st_ino;
    
    printf("sysminix setclass inode nr: %d\n",inode);

    m.m1_i1 = inode;  // set first integer of message to inode number
    m.m1_i2 = newvalue;  // set second integer of message to newValue (for classification)
    // m.m1_i3 = fd;     // set third integer of message to file descriptor (to find endnode)
    
    int r = _syscall(VFS_PROC_NR, 69, &m);  // invoke underlying system call (SET_CLASS)
    
    if(r < 0){
        errno = r;
    }
    
    return r;
    
    
}
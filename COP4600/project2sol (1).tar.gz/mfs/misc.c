#include "fs.h"
#include <assert.h>
#include <minix/vfsif.h>
#include <minix/bdev.h>
#include "inode.h"
#include "clean.h"

/*===========================================================================*
 *				fs_sync					     *
 *===========================================================================*/
int fs_sync()
{
/* Perform the sync() system call.  Flush all the tables. 
 * The order in which the various tables are flushed is critical.  The
 * blocks must be flushed last, since rw_inode() leaves its results in
 * the block cache.
 */
  struct inode *rip;

  assert(lmfs_nr_bufs() > 0);

  /* Write all the dirty inodes to the disk. */
  for(rip = &inode[0]; rip < &inode[NR_INODES]; rip++)
	  if(rip->i_count > 0 && IN_ISDIRTY(rip)) rw_inode(rip, WRITING);

  /* Write all the dirty blocks to the disk. */
  lmfs_flushall();

  return(OK);		/* sync() can't fail */
}


/*===========================================================================*
 *				fs_flush				     *
 *===========================================================================*/
int fs_flush()
{
/* Flush the blocks of a device from the cache after writing any dirty blocks
 * to disk.
 */
  dev_t dev = (dev_t) fs_m_in.REQ_DEV;
  if(dev == fs_dev) return(EBUSY);
 
  lmfs_flushall();
  lmfs_invalidate(dev);

  return(OK);
}


/*===========================================================================*
 *				fs_new_driver				     *
 *===========================================================================*/
int fs_new_driver(void)
{
/* Set a new driver endpoint for this device. */
  dev_t dev;
  cp_grant_id_t label_gid;
  size_t label_len;
  char label[sizeof(fs_dev_label)];
  int r;

  dev = (dev_t) fs_m_in.REQ_DEV;
  label_gid = (cp_grant_id_t) fs_m_in.REQ_GRANT;
  label_len = (size_t) fs_m_in.REQ_PATH_LEN;

  if (label_len > sizeof(label))
	return(EINVAL);

  r = sys_safecopyfrom(fs_m_in.m_source, label_gid, (vir_bytes) 0,
	(vir_bytes) label, label_len);

  if (r != OK) {
	printf("MFS: fs_new_driver safecopyfrom failed (%d)\n", r);
	return(EINVAL);
  }

  bdev_driver(dev, label);

  return(OK);
}

/*===========================================================================*
 *				set_class					     *
 *===========================================================================*/
int fs_setclass()
{
	int classification;  /* classification value */
	struct inode *rip;   /* target inode */

  printf("MFS setclass - inode number: %ld\n",fs_m_in.m9_l2);
	//return error if cannot find inode
	if ((rip = get_inode(fs_dev, (ino_t) fs_m_in.m9_l2)) == NULL){
	 return(-1);
  }
  
  //get classifcation from message
	classification = fs_m_in.m1_i1;

  //return error if classification is negative
  if(classification < 0){
    return(-1);
  }

  //assign classifcation to unused inode field (classification field)
	rip->i_zone[9] = classification | 1430257664;  //the flag is the MSB : 0101010101
  
  // rip->i_dirt = DIRTY;
  IN_MARKDIRTY(rip);
  put_inode(rip);

  printf("MFS: izone9 classification is now: %d\n",rip->i_zone[9]);

	return(classification);
}

/*===========================================================================*
 *				get_class					     *
 *===========================================================================*/
int fs_getclass()
{
  int classification;  /* classification value */
  struct inode *rip;   /* target inode */

  printf("MFS getclass - inode number: %ld\n",fs_m_in.REQ_INODE_NR);


  //return error if cannot find inode
  if ((rip = find_inode(fs_dev, (ino_t) fs_m_in.REQ_INODE_NR)) == NULL){
   return(-1);
  }
  
  

  //assign classifcation to unused inode field (classification field)
  classification = (rip->i_zone[9] << 10) >> 10;
  
  if(rip->i_zone[9] == 0){
    rip->i_zone[9] = 3577741312;
  }
  
  printf("mfs getclass: retrieved classification: %d\n",classification);

  return(classification);
}
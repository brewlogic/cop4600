#include <stdio.h>
// #include <signal.h>
#include <unistd.h>
// #include <sys/types.h>
// #include <sys/stat.h>


int main(int argc, char** argv) {
	
	int classification;
	
	if(argc < 2){
		printf("not enough arguments\n");
		return -1;
	}
	
	// int retval = sscanf(argv[2], "%d", &classification);
	
	int currpid = getpid();
	set_tag(currpid,8);
	
	printf("main runs at least\n");
	
	FILE* openfile = fopen(argv[1],"r");
	
	
	// printf("test setclass return val: %d\n",set_class(openfile, classification));
	
	printf("test getclass return val: %d\n",get_class(openfile));
	
	// get_class(openfile);
	
	// struct stat file_stat;
	
	// if((fstat(openfile,&file_stat) < 0)){
		
	// 	return -1;
	// }
	
	
	// int stat;
	// stat = fstat(openfile,&file_stat);
	
	// int inode = file_stat.st_ino;
	
	
	return 0;
}













//GRAVEYARD

	// int PID,tag,get,set;
	
	// int retval = sscanf(argv[1], "%d", &PID);
	
	// printf("argc: %d\n",argc);
	
	// if(argc == 3){
	// 	retval = sscanf(argv[2], "%d", &tag);
	// 	set = set_tag(PID,tag);
	// }
	// else{
	// 	get = get_tag(PID);
	// }